function Employee(props){
    return(

        <>
            <tr>
                
                <td>{props.name}</td>
                <td>{props.department}</td>
            </tr>
            
        </>
    )
}
export default Employee