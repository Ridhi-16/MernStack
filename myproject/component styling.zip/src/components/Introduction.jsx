function Introduction(){
    return(
        <>
        <h1 style={{color:"purple", backgroundColor:"pink"}}>Introduction</h1>
        <h1 style={{color:"red",backgroundColor:"yellow"}}>Hi My Name is Ridhi</h1>
        <ul>
            <li>I am doing B.Tech in CSE</li>
            <li>My course is MERN</li>
            <li>This is an example of functional components in <strong>React</strong></li>
        </ul>
        </>
    )
}


export default Introduction