function Introduction(){
    return(
        <>
        <h1 style={{color:"purple", backgroundColor:"pink"}}>Introduction</h1>
        <h1 style={{color:"red",backgroundColor:"yellow"}}>Hi My Name is ridhi</h1>
        <p>I am doing B.Tech in CSE</p>
        <p>this is an example of functional components in <strong>React</strong></p>
        </>
    )
}


export default Introduction