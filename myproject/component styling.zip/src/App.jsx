import Introduction from "./components/Introduction"
import Div from "./components/Div"

function App(){
  return(
    <>
    <Introduction/>
    <Div/>
    </>
  )
}

export default App
