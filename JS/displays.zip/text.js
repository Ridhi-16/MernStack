function func1(){
    document.getElementById("para").style.display="block"
    document.getElementById("button1").style.display="none"
    document.getElementById("button2").style.display="block"

}
function func2(){
    document.getElementById("para").style.display="none"
    document.getElementById("button2").style.display="none"
    document.getElementById("button1").style.display="block"
}